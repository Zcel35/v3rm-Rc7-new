﻿namespace Rc7
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtUsername = new RichTextBox();
            txtPassword = new RichTextBox();
            lblLoginButton = new Label();
            SuspendLayout();
            // 
            // txtUsername
            // 
            txtUsername.BackColor = Color.FromArgb(24, 24, 24);
            txtUsername.BorderStyle = BorderStyle.None;
            txtUsername.Font = new Font("Consolas", 10F);
            txtUsername.ForeColor = Color.White;
            txtUsername.Location = new Point(76, 112);
            txtUsername.Multiline = true;
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(152, 22);
            txtUsername.TabIndex = 0;
            txtUsername.ScrollBars = RichTextBoxScrollBars.None;
            txtUsername.WordWrap = false;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(24, 24, 24);
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Font = new Font("Consolas", 10F);
            txtPassword.ForeColor = Color.White;
            txtPassword.Location = new Point(76, 140);
            txtPassword.Multiline = true;
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(152, 23);
            txtPassword.TabIndex = 1;
            txtPassword.ScrollBars = RichTextBoxScrollBars.None;
            txtPassword.WordWrap = false;
            // 
            // lblLoginButton
            // 
            lblLoginButton.BackColor = Color.FromArgb(24, 24, 24);
            lblLoginButton.Cursor = Cursors.Hand;
            lblLoginButton.Font = new Font("Arial", 8F, FontStyle.Bold);
            lblLoginButton.ForeColor = Color.White;
            lblLoginButton.Location = new Point(102, 170);
            lblLoginButton.Name = "lblLoginButton";
            lblLoginButton.Size = new Size(100, 30);
            lblLoginButton.TabIndex = 2;
            lblLoginButton.Text = "Submit";
            lblLoginButton.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(339, 328);
            Controls.Add(lblLoginButton);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            Name = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.RichTextBox txtUsername;
        private System.Windows.Forms.RichTextBox txtPassword;
        private System.Windows.Forms.Label lblLoginButton;
    }
}