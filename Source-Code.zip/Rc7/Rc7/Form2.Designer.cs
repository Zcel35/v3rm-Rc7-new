﻿namespace Rc7
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            fctbLua = new FastColoredTextBoxNS.FastColoredTextBox();
            rtbOutput = new RichTextBox();
            picOpen = new PictureBox();
            picExecute = new PictureBox();
            picClear = new PictureBox();
            lblOpen = new Label();
            lblExecute = new Label();
            lblClear = new Label();
            btnSave = new Button();
            btnWordWrap = new Button();
            btnAutoexec = new Button();
            btnDrive = new Button();
            btnRunRo = new Button();
            btnRunDex = new Button();
            ((System.ComponentModel.ISupportInitialize)fctbLua).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picOpen).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picExecute).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picClear).BeginInit();
            SuspendLayout();

            fctbLua.AutoCompleteBracketsList = new char[]
            {
                '(', ')', '{', '}', '[', ']', '"', '"', '\'', '\''
            };
            fctbLua.AutoScrollMinSize = new Size(2, 14);
            fctbLua.BackBrush = null;
            fctbLua.CharHeight = 14;
            fctbLua.CharWidth = 8;
            fctbLua.Cursor = Cursors.IBeam;
            fctbLua.DisabledColor = Color.FromArgb(100, 180, 180, 180);
            fctbLua.Font = new Font("Courier New", 9.75F);
            fctbLua.IsReplaceMode = false;
            fctbLua.Location = new Point(12, 12);
            fctbLua.Name = "fctbLua";
            fctbLua.Paddings = new Padding(0);
            fctbLua.SelectionColor = Color.FromArgb(60, 0, 0, 255);
            fctbLua.ServiceColors = (FastColoredTextBoxNS.ServiceColors)resources.GetObject("fctbLua.ServiceColors");
            fctbLua.Size = new Size(277, 230);
            fctbLua.TabIndex = 0;
            fctbLua.Zoom = 100;

            rtbOutput.Location = new Point(12, 273);
            rtbOutput.Name = "rtbOutput";
            rtbOutput.Size = new Size(281, 75);
            rtbOutput.TabIndex = 4;
            rtbOutput.Text = "";

            picOpen.Location = new Point(12, 243);
            picOpen.Name = "picOpen";
            picOpen.Size = new Size(100, 29);
            picOpen.TabIndex = 1;
            picOpen.TabStop = false;

            picExecute.Location = new Point(108, 243);
            picExecute.Name = "picExecute";
            picExecute.Size = new Size(96, 29);
            picExecute.TabIndex = 2;
            picExecute.TabStop = false;

            picClear.Location = new Point(205, 243);
            picClear.Name = "picClear";
            picClear.Size = new Size(88, 29);
            picClear.TabIndex = 3;
            picClear.TabStop = false;

            lblOpen.BackColor = Color.Transparent;
            lblOpen.Cursor = Cursors.Hand;
            lblOpen.Dock = DockStyle.Fill;
            lblOpen.Location = new Point(0, 0);
            lblOpen.Name = "lblOpen";
            lblOpen.Size = new Size(100, 29);
            lblOpen.TabIndex = 0;
            lblOpen.Text = "Open";
            lblOpen.TextAlign = ContentAlignment.MiddleCenter;

            lblExecute.BackColor = Color.Transparent;
            lblExecute.Cursor = Cursors.Hand;
            lblExecute.Dock = DockStyle.Fill;
            lblExecute.Location = new Point(0, 0);
            lblExecute.Name = "lblExecute";
            lblExecute.Size = new Size(96, 29);
            lblExecute.TabIndex = 0;
            lblExecute.Text = "Execute";
            lblExecute.TextAlign = ContentAlignment.MiddleCenter;

            lblClear.BackColor = Color.Transparent;
            lblClear.Cursor = Cursors.Hand;
            lblClear.Dock = DockStyle.Fill;
            lblClear.Location = new Point(0, 0);
            lblClear.Name = "lblClear";
            lblClear.Size = new Size(88, 29);
            lblClear.TabIndex = 0;
            lblClear.Text = "Clear";
            lblClear.TextAlign = ContentAlignment.MiddleCenter;

            btnSave.BackColor = Color.Transparent;
            btnSave.Cursor = Cursors.Hand;
            btnSave.FlatAppearance.BorderSize = 0;
            btnSave.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnSave.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Font = new Font("Arial", 8F, FontStyle.Bold);
            btnSave.ForeColor = Color.Transparent;
            btnSave.Location = new Point(305, 119);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(30, 30);
            btnSave.TabIndex = 5;
            btnSave.Text = "";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;

            btnWordWrap.BackColor = Color.Transparent;
            btnWordWrap.Cursor = Cursors.Hand;
            btnWordWrap.FlatAppearance.BorderSize = 0;
            btnWordWrap.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnWordWrap.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnWordWrap.FlatStyle = FlatStyle.Flat;
            btnWordWrap.Font = new Font("Arial", 8F, FontStyle.Bold);
            btnWordWrap.ForeColor = Color.Transparent;
            btnWordWrap.Location = new Point(305, 160);
            btnWordWrap.Name = "btnWordWrap";
            btnWordWrap.Size = new Size(30, 30);
            btnWordWrap.TabIndex = 6;
            btnWordWrap.Text = "";
            btnWordWrap.UseVisualStyleBackColor = false;
            btnWordWrap.Click += btnWordWrap_Click;

            btnAutoexec.BackColor = Color.Transparent;
            btnAutoexec.Cursor = Cursors.Hand;
            btnAutoexec.FlatAppearance.BorderSize = 0;
            btnAutoexec.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnAutoexec.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnAutoexec.FlatStyle = FlatStyle.Flat;
            btnAutoexec.Font = new Font("Arial", 8F, FontStyle.Bold);
            btnAutoexec.ForeColor = Color.Transparent;
            btnAutoexec.Location = new Point(305, 200);
            btnAutoexec.Name = "btnAutoexec";
            btnAutoexec.Size = new Size(30, 30);
            btnAutoexec.TabIndex = 7;
            btnAutoexec.Text = "";
            btnAutoexec.UseVisualStyleBackColor = false;
            btnAutoexec.Click += btnAutoexec_Click;

            btnDrive.BackColor = Color.Transparent;
            btnDrive.Cursor = Cursors.Hand;
            btnDrive.FlatAppearance.BorderSize = 0;
            btnDrive.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnDrive.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnDrive.FlatStyle = FlatStyle.Flat;
            btnDrive.Font = new Font("Arial", 8F, FontStyle.Bold);
            btnDrive.ForeColor = Color.Transparent;
            btnDrive.Location = new Point(305, 240);
            btnDrive.Name = "btnDrive";
            btnDrive.Size = new Size(30, 30);
            btnDrive.TabIndex = 8;
            btnDrive.Text = "";
            btnDrive.UseVisualStyleBackColor = false;
            btnDrive.Click += btnDrive_Click;

            btnRunRo.BackColor = Color.Transparent;
            btnRunRo.Cursor = Cursors.Hand;
            btnRunRo.FlatAppearance.BorderSize = 0;
            btnRunRo.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnRunRo.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnRunRo.FlatStyle = FlatStyle.Flat;
            btnRunRo.Font = new Font("Arial", 8F, FontStyle.Bold);
            btnRunRo.ForeColor = Color.Transparent;
            btnRunRo.Location = new Point(305, 283);
            btnRunRo.Name = "btnRunRo";
            btnRunRo.Size = new Size(30, 30);
            btnRunRo.TabIndex = 9;
            btnRunRo.Text = "";
            btnRunRo.UseVisualStyleBackColor = false;
            btnRunRo.Click += btnRunRo_Click;

            btnRunDex.BackColor = Color.Transparent;
            btnRunDex.Cursor = Cursors.Hand;
            btnRunDex.FlatAppearance.BorderSize = 0;
            btnRunDex.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnRunDex.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnRunDex.FlatStyle = FlatStyle.Flat;
            btnRunDex.Font = new Font("Arial", 8F, FontStyle.Bold);
            btnRunDex.ForeColor = Color.Transparent;
            btnRunDex.Location = new Point(305, 323);
            btnRunDex.Name = "btnRunDex";
            btnRunDex.Size = new Size(30, 30);
            btnRunDex.TabIndex = 10;
            btnRunDex.Text = "";
            btnRunDex.UseVisualStyleBackColor = false;
            btnRunDex.Click += btnRunDex_Click;

            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(339, 360);
            Controls.Add(btnRunDex);
            Controls.Add(btnRunRo);
            Controls.Add(btnDrive);
            Controls.Add(btnAutoexec);
            Controls.Add(btnWordWrap);
            Controls.Add(btnSave);
            Controls.Add(lblClear);
            Controls.Add(lblExecute);
            Controls.Add(lblOpen);
            Controls.Add(picClear);
            Controls.Add(picExecute);
            Controls.Add(picOpen);
            Controls.Add(rtbOutput);
            Controls.Add(fctbLua);
            Name = "Form2";
            ((System.ComponentModel.ISupportInitialize)fctbLua).EndInit();
            ((System.ComponentModel.ISupportInitialize)picOpen).EndInit();
            ((System.ComponentModel.ISupportInitialize)picExecute).EndInit();
            ((System.ComponentModel.ISupportInitialize)picClear).EndInit();
            ResumeLayout(false);
        }

        private FastColoredTextBoxNS.FastColoredTextBox fctbLua;
        private System.Windows.Forms.RichTextBox rtbOutput;
        private System.Windows.Forms.PictureBox picOpen;
        private System.Windows.Forms.PictureBox picExecute;
        private System.Windows.Forms.PictureBox picClear;
        private System.Windows.Forms.Label lblOpen;
        private System.Windows.Forms.Label lblExecute;
        private System.Windows.Forms.Label lblClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnWordWrap;
        private System.Windows.Forms.Button btnAutoexec;
        private System.Windows.Forms.Button btnDrive;
        private System.Windows.Forms.Button btnRunRo;
        private System.Windows.Forms.Button btnRunDex;
    }
}