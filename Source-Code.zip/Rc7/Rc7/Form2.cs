﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Rc7
{
    public partial class Form2 : Form
    {
        public enum UISetting { AutoAttach = 0, DiscordRPC = 1 }

        [DllImport("v3rmbypass.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private static extern void Initialize(bool useConsole);
        [DllImport("v3rmbypass.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void SetSetting(UISetting settingID, int value);
        [DllImport("v3rmbypass.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private static extern IntPtr GetClients();
        [DllImport("v3rmbypass.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private static extern IntPtr Version();
        [DllImport("v3rmbypass.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private static extern void Execute(byte[] script, int[] PIDs, int count);
        [DllImport("v3rmbypass.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void Attach();

        public Form2()
        {
            InitializeComponent();
            this.Text = "";
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            this.TopMost = true;

            try { this.Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            try
            {
                Initialize(false);
                SetSetting(UISetting.AutoAttach, 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("v3rmbypass.dll не загрузилась: " + ex.Message,
                    "RC7", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            this.FormClosed += (s, ev) => Form1.CleanAutoexecFolder();

            this.Load += Form2_Load;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                string bgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "theme", "MainUi.bmp");
                if (File.Exists(bgPath))
                {
                    this.BackgroundImage = Image.FromFile(bgPath);
                    this.BackgroundImageLayout = ImageLayout.Stretch;
                }
                else this.BackColor = Color.Black;
            }
            catch { this.BackColor = Color.Black; }

            try
            {
                fctbLua.ServiceColors = new ServiceColors();
                fctbLua.ShowFoldingLines = false;
                fctbLua.HighlightFoldingIndicator = false;
                fctbLua.Language = Language.Lua;
                fctbLua.Text = "";
                fctbLua.BackColor = Color.White;
                fctbLua.ForeColor = Color.Black;
                fctbLua.Font = new Font("Consolas", 10);
            }
            catch { }

            rtbOutput.BackColor = Color.White;
            rtbOutput.ForeColor = Color.Black;
            rtbOutput.Font = new Font("Consolas", 9);
            rtbOutput.ReadOnly = true;
            rtbOutput.BorderStyle = BorderStyle.None;
            rtbOutput.Text = "";

            SetupButton(picOpen, lblOpen);
            SetupButton(picExecute, lblExecute);
            SetupButton(picClear, lblClear);

            RemoveFocus(btnSave);
            RemoveFocus(btnWordWrap);
            RemoveFocus(btnAutoexec);
            RemoveFocus(btnDrive);
            RemoveFocus(btnRunRo);
            RemoveFocus(btnRunDex);
        }

        private void RemoveFocus(Control ctrl)
        {
            ctrl.TabStop = false;
            MethodInfo mi = typeof(Control).GetMethod("SetStyle",
                BindingFlags.Instance | BindingFlags.NonPublic);
            mi.Invoke(ctrl, new object[] { ControlStyles.Selectable, false });
            mi.Invoke(ctrl, new object[] { ControlStyles.UserMouse, true });
        }

        private void SetupButton(PictureBox pic, Label lbl)
        {
            try
            {
                string btnPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "theme", "S_Button_Idle_1.bmp");
                if (File.Exists(btnPath))
                {
                    pic.Image = Image.FromFile(btnPath);
                    pic.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                else pic.BackColor = Color.Red;
            }
            catch { pic.BackColor = Color.Red; }

            RemoveFocus(pic);

            pic.Controls.Add(lbl);
            lbl.Dock = DockStyle.Fill;
            lbl.ForeColor = Color.White;
            lbl.Font = new Font("Arial", 8F, FontStyle.Bold);
            lbl.BackColor = Color.Transparent;

            pic.Click += (s, e) => ButtonClick(pic);
            lbl.Click += (s, e) => ButtonClick(pic);
        }

        private void ButtonClick(PictureBox pic)
        {
            if (pic == picOpen) DoOpen();
            else if (pic == picExecute) DoExecute();
            else if (pic == picClear) DoClear();
        }

        private void DoOpen()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Lua Scripts (*.lua)|*.lua|All Files (*.*)|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
                fctbLua.Text = File.ReadAllText(ofd.FileName);
        }

        private void DoExecute()
        {
            try
            {
                int[] pids = GetActiveClientPids();
                if (pids == null || pids.Length == 0) return;

                byte[] scriptBytes = Encoding.UTF8.GetBytes(fctbLua.Text + "\0");
                Execute(scriptBytes, pids, pids.Length);
            }
            catch { }
        }

        private void DoClear()
        {
            fctbLua.Clear();
        }

        private int[] GetActiveClientPids()
        {
            var list = new System.Collections.Generic.List<int>();
            IntPtr ptr = GetClients();
            if (ptr == IntPtr.Zero) return list.ToArray();

            string json = Marshal.PtrToStringAnsi(ptr);
            if (string.IsNullOrEmpty(json)) return list.ToArray();

            try
            {
                JArray arr = JsonConvert.DeserializeObject<JArray>(json);
                if (arr == null) return list.ToArray();

                foreach (JToken item in arr)
                {
                    if (item is JArray row && row.Count >= 4)
                    {
                        int id = row[0].Value<int>();
                        int state = row[3].Value<int>();
                        if (state == 3) list.Add(id);
                    }
                }
            }
            catch { }

            return list.ToArray();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Lua Scripts (*.lua)|*.lua|All Files (*.*)|*.*";
            sfd.DefaultExt = "lua";
            if (sfd.ShowDialog() == DialogResult.OK)
                File.WriteAllText(sfd.FileName, fctbLua.Text);
        }

        private void btnWordWrap_Click(object sender, EventArgs e) { }
        private void btnAutoexec_Click(object sender, EventArgs e) { }

        private void btnDrive_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://sun9-71.vkuserphoto.ru/X_b_hwx1eXllKHYlQ6d43a4dXnb_kkLi1P22AA/aR-bUuTpwJs.jpg",
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private void btnRunRo_Click(object sender, EventArgs e)
        {
            try
            {
                int[] pids = GetActiveClientPids();
                if (pids == null || pids.Length == 0) return;
                string script = "loadstring(game:GetObjects('rbxassetid://364364477')[1].Source)()";
                byte[] scriptBytes = Encoding.UTF8.GetBytes(script + "\0");
                Execute(scriptBytes, pids, pids.Length);
            }
            catch { }
        }

        private void btnRunDex_Click(object sender, EventArgs e)
        {
            try
            {
                int[] pids = GetActiveClientPids();
                if (pids == null || pids.Length == 0) return;
                string script = "loadstring(game:GetObjects('rbxassetid://2180084478')[1].Source)()";
                byte[] scriptBytes = Encoding.UTF8.GetBytes(script + "\0");
                Execute(scriptBytes, pids, pids.Length);
            }
            catch { }
        }
    }
}