using System;
using System.Windows.Forms;

namespace Rc7
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            using (Form1 login = new Form1())
            {
                if (login.ShowDialog() == DialogResult.OK)
                {
                    Application.Run(new Form2());
                }
            }
        }
    }
}